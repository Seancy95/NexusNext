NEXUS NEXT B03-WP02-A-R01 — WINDOWS DESIGN PACKAGE
=====================================================

Methodology correction commit: cc0ab4f4cc333ad962ee164c8ab4ea5838180cbb
Validation/provenance commit:   1f01360c3a5d24c56821bf69573257cd0ad5b53e
Branch:                         b03-wp02-a-r01

Open docs\B03-WP02-A\README.md and CHANGELOG_R01.md first.

Verify all design files in Windows PowerShell:

  powershell -NoProfile -ExecutionPolicy Bypass -File .\VERIFY_FILES.ps1

The script requires no administrator rights and changes no security policy.

STATUS
------
WP02-A-R01 recommendation: Conditional design acceptance after independent review
WP02-B readiness: Not Ready
WP02-B implementation: Not Authorised / Not Implemented
Comparator: Not Implemented
Hidden scenarios: Not Created
Operational hidden separation: Not Implemented
Benchmark execution: Not Run
Independent verification: Not Verified

This package contains corrected design documentation and templates only.
