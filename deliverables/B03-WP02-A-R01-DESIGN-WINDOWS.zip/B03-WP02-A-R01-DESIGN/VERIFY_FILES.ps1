$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$manifest = Join-Path $PSScriptRoot 'docs\B03-WP02-A\SHA256SUMS.txt'
$failed = $false
foreach ($line in Get-Content -LiteralPath $manifest) {
    if ($line -notmatch '^([0-9a-f]{64})  (.+)$') { throw "Malformed manifest line: $line" }
    $expected = $Matches[1].ToUpperInvariant()
    $relative = $Matches[2] -replace '/', '\'
    $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $PSScriptRoot $relative)).Hash
    if ($actual -ne $expected) { Write-Host "FAILED: $relative" -ForegroundColor Red; $failed = $true }
    else { Write-Host "OK: $relative" }
}
if ($failed) { exit 1 }
Write-Host 'All packaged R01 design files passed SHA-256 verification.' -ForegroundColor Green
exit 0
