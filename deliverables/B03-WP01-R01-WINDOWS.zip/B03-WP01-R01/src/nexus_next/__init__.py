"""Nexus Next product package."""
