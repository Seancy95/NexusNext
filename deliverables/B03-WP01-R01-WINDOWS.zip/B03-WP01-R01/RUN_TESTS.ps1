$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$env:PYTHONPATH = Join-Path (Get-Location) 'src'
& py -3 -m unittest discover -s tests\wp01 -t . -v
exit $LASTEXITCODE
