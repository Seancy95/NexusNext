NEXUS NEXT B03-WP01-R01 — WINDOWS REVIEW PACKAGE
=====================================================

Corrective source commit: a7ab0e63a27731f806921e0c3e65ebed4fcac812
Evidence commit:          a9728c1f2726e359b8c9bed7fbc06e3a0269d4da
Branch:                   b03-wp01-r01

CONTENTS
--------
- Corrected foundational contract source under src\nexus_next
- Frozen registry under config
- Original and R01 synthetic tests under tests\wp01
- Defect closure, authority audit, manifests and transcripts under docs
- RUN_TESTS.ps1 for non-administrator Windows execution

WINDOWS EXECUTION
-----------------
Requirement: Python 3.11 or newer available through the Windows `py` launcher.

1. Extract this ZIP in Windows Explorer.
2. Open Windows PowerShell in the extracted B03-WP01-R01 folder.
3. Run:

   powershell -NoProfile -ExecutionPolicy Bypass -File .\RUN_TESTS.ps1

The ExecutionPolicy argument applies only to this process and does not change the
machine or user policy. The script performs no elevation or security-policy change.

EXPECTED DEVELOPER RESULT
-------------------------
91 passed, 0 failed, 0 skipped. This result was observed on cloud-hosted Linux
using Python 3.12.14. Windows execution has not yet occurred and is not claimed.
Independent verification remains Not Verified. WP01 is not formally closed.

Passing WP01 contract and conformance tests does not establish analytical
correctness, investigative competence, secure IPC, Windows isolation, canonical
report fidelity or production readiness.
