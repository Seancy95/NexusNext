B03-WP01 FOUNDATIONAL INVESTIGATION CONTRACTS
=================================================

Package source revision: e8f725508f1d0c2e0f8ffd6f9290f714355908be
Implementation commit:  9552fa8a12933b388a73cb31c4d1a27156996794
Branch:                 b03-wp01-implementation

CONTENTS
--------
- Foundational investigation contract source under src\nexus_next
- Frozen contract registry under config
- Synthetic conformance tests under tests\wp01
- WP01 readiness and implementation evidence under docs

WINDOWS TEST COMMAND (NON-ADMINISTRATOR)
----------------------------------------
Requirements: Python 3.11 or newer. The cloud verification used Python 3.12.14.

1. Extract this ZIP in Windows Explorer.
2. Open Windows PowerShell in the extracted B03-WP01-IMPLEMENTATION folder.
3. Run:

   $env:PYTHONPATH = (Join-Path (Get-Location) 'src')
   py -3 -m unittest discover -s tests\wp01 -t . -v

The tests passed in the Codex Linux cloud environment. They have not been run on
Windows, so this package does not claim Windows verification.

SCOPE AND LIMITATIONS
---------------------
Passing WP01 contract and conformance tests does not establish analytical
correctness, investigative competence, secure IPC, Windows isolation, canonical
report fidelity or production readiness.

Independent technical verification remains Not Verified. This package contains
only WP01 tracked source, configuration, synthetic tests, and documentation.
It excludes unrelated local, G2, Phase 0, B01, generated, ignored, and sensitive
material.
