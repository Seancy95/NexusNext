NEXUS NEXT B03-WP02-A — WINDOWS DESIGN PACKAGE
================================================

Design commit:     7e60ec53e4d807dc3b697c473e656666e0041692
Evidence commit:   77959ff0862943c84cff4ed7e8215ff503b70f62
Branch:            b03-wp02-a-design

Open docs\B03-WP02-A\README.md first.

To verify every packaged design file in Windows PowerShell:

  powershell -NoProfile -ExecutionPolicy Bypass -File .\VERIFY_FILES.ps1

The script reads docs\B03-WP02-A\SHA256SUMS.txt and performs local SHA-256
checks. It requires no administrator rights and changes no security policy.

STATUS
------
Evaluation design: Delivered for review
WP02-B implementation: Not Authorised / Not Implemented
Hidden scenarios: Not Created
Benchmark execution: Not Run
Independent verification: Not Verified

This package contains design documentation and CSV/JSON templates only.
